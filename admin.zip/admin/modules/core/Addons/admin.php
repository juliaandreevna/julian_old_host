<?php

$app->bindClass("Addons\\Controller\\Addons", "settings/addons");
