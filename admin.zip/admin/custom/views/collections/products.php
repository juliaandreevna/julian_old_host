@start('header')

    {{ $app->assets(['collections:assets/collections.js','collections:assets/js/entries.js'], $app['cockpit/version']) }}
    {{ $app->assets(['assets:js/angular/directives/mediapreview.js'], $app['cockpit/version']) }}

    @trigger('cockpit.content.fields.sources')

    @if($collection['sortfield'] == 'custom-order')

        {{ $app->assets(['assets:vendor/uikit/js/components/sortable.min.js'], $app['cockpit/version']) }}

    @endif

    <style>

        td .uk-grid+.uk-grid { margin-top: 5px; }

        .type-media .media-url-preview {
            border-radius: 50%;
        }

        .uk-sortable-dragged {
            border: 1px #ccc dashed;
            height: 40px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 2px;
        }

        .uk-sortable-dragged td {
            display: none;
        }
        .image {
            text-align: center;
        }
        .image .uk-dropdown {
            left: 60px;
            top: 0px;
        }
        .title {
        }
        
        .price {
        }

    </style>

    <script>
        var COLLECTION = {{ json_encode($collection) }};
        var FILTER = {{ json_encode($app->param('filter', '')) }};
    </script>

@end('header')



<div data-ng-controller="entries" ng-cloak>

    <nav class="uk-navbar uk-margin-bottom">
        <span class="uk-navbar-brand"><a href="@route("/collections")">@lang('Collections')</a> / {{ $collection['name'] }}</span>
        <ul class="uk-navbar-nav">
            @hasaccess?("Collections", 'manage.collections')
            <li><a href="@route('/collections/collection/'.$collection["_id"])" title="@lang('Edit collection')" data-uk-tooltip="{pos:'bottom'}"><i class="uk-icon-pencil"></i></a></li>
            @hasaccess?("Collections", 'view.all.entries')
            <li class="uk-hidden"><a class="uk-text-danger" ng-click="emptytable()" title="@lang('Empty collection')" data-uk-tooltip="{pos:'bottom'}"><i class="uk-icon-trash-o"></i></a></li>
            @end
            @end
            <li><a href="@route('/collections/entry/'.$collection["_id"])" title="@lang('Add entry')" data-uk-tooltip="{pos:'bottom'}"><i class="uk-icon-plus-circle"></i></a></li>
        </ul>

        @if($collection['sortfield'] != 'custom-order')
        <div class="uk-navbar-content" data-ng-show="collection && collection.count">
            <form class="uk-form uk-margin-remove uk-display-inline-block" method="get" action="?nc={{ time() }}">
                <div class="uk-form-icon">
                    <i class="uk-icon-filter"></i>
                    <input type="text" placeholder="@lang('Filter entries...')" name="filter[search]" value="@@ filter['search'] @@"> &nbsp;
                    <a class="uk-text-small" href="@route('/collections/entries/'.$collection['_id'])" data-ng-show="filter"><i class="uk-icon-times"></i> @lang('Reset filter')</a>
                </div>
            </form>
        </div>
        @endif

        <div class="uk-navbar-flip">
            @hasaccess?("Collections", 'manage.collections')
            <ul class="uk-navbar-nav">
                <li>
                    <a href="@route('/api/collections/export/'.$collection['_id'])" download="{{ $collection['name'] }}.json" title="@lang('Export data')" data-uk-tooltip="{pos:'bottom'}">
                        <i class="uk-icon-share-alt"></i>
                    </a>
                </li>
            </ul>
            @end
        </div>
    </nav>
    
    <nav class="uk-navbar uk-margin-bottom">
        <form class="uk-form" method="get" action="?nc={{ time() }}">
            <ul class="uk-navbar-nav">            
                <li class="uk-margin-right uk-margin-bottom" data-ng-repeat="field in filter_fields" data-ng-if="field.filter==true">
                    <span>@@ field.label @@:</span>
                    
                    <contentfield data-name="filter[@@ field.name @@]" data-ng-if="field.type=='link-collection'" options="@@ field @@" ng-model="filter[field.name]"></contentfield>
                    
                    <contentfield data-name="filter[@@ field.name @@]" data-ng-if="field.type=='select'" options="@@ field @@" ng-model="filter[field.name]"></contentfield>
                    
                    <select name="filter[@@ field.name @@]" data-ng-if="field.type=='select1'">
                        <option data-ng-repeat="option in field.options" value="@@ option.value @@" ng-selected="option.value=='@@ filter[field.name] @@'">@@ option.label @@</option>
                    </select>
                    <span data-ng-if="field.type=='text'">
                        от <input class="uk-form-width-small" name="filter[@@ field.name @@][min]" value="@@ filter[field.name]['min'] @@">
                        до <input class="uk-form-width-small" name="filter[@@ field.name @@][max]" value="@@ filter[field.name]['max'] @@">
                    </span>
                    
                    <select name="filter[@@ field.name @@]" ng-model="filter[field.name]" data-ng-if="field.type=='boolean'">
                        <option value="true">Да</option>
                        <option value="false">Нет</option>
                        <option value="null">Не важно</option>
                    </select>
                </li>
                <li><input type="submit" value="Фильтровать" class="uk-button uk-button-primary"></li>
            </ul>
        </form>
    </nav>

    <div class="app-panel uk-margin uk-text-center" data-ng-show="entries && !filter && !entries.length">
        <h2><i class="uk-icon-list"></i></h2>
        <p class="uk-text-large">
            @lang('It seems you don\'t have any entries created.')
        </p>
        <a href="@route('/collections/entry/'.$collection["_id"])" class="uk-button uk-button-success uk-button-large">@lang('Add entry')</a>
    </div>

    <div class="app-panel uk-margin uk-text-center" data-ng-show="entries && filter && !entries.length">
        <h2><i class="uk-icon-search"></i></h2>
        <p class="uk-text-large">
            @lang('No entries found.')
        </p>
    </div>

    <div class="uk-grid" data-uk-grid-margin data-ng-show="entries && entries.length">

        <div class="uk-width-1-1">
            <div class="app-panel">
                <table id="entries-table" class="uk-table uk-table-striped" multiple-select="{model:entries}">
                    <thead>
                        <tr>
                            <th width="10"><input class="js-select-all" type="checkbox"></th>
                            <th width="15">№</th>
                            <th>Фото</th>
                            <th width="10%">Штрихкод</th>
                            <th>Наименование</th>
                            <th>Упаковка</th>
                            <th>Цена опт.</th>
                            <th width="10%">&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody {{ $collection['sortfield'] == 'custom-order' ? 'data-uk-sortable="{animation:false}"':'' }}>
                        <tr class="js-multiple-select" data-ng-repeat="entry in entries track by entry._id">
                            <td><input class="js-select" type="checkbox"></td>
                            <td>@@ $index+1 @@</td>
                            <td>
                                <div class="image" data-uk-dropdown>
                                    <img ng-src="@route('/mediamanager/thumbnail')/@@ entry['photo'][0].path|base64 @@/35/35" title="@@ entry['title'] @@">
                                    <div class="uk-dropdown"><img ng-src="@route('/mediamanager/thumbnail')/@@ entry['photo'][0].path|base64 @@/150/150" title="@@ entry['title'] @@"></div>
                                </div>
                            </td>
                            <td><span class="barcode">@@ entry.barcode @@</span></td>
                            <td><span class="title"><a href="@route('/collections/entry/'.$collection["_id"])/@@ entry._id @@" target="_blank">@@ entry.name @@</a></span></td>
                            <td></td>
                            <td><span class="price">@@ entry.wholesale @@ руб</span></td>
                            <td class="uk-text-right">
                                <div data-uk-dropdown>
                                    <i class="uk-icon-bars"></i>
                                    <div class="uk-dropdown uk-dropdown-flip uk-text-left">
                                        <ul class="uk-nav uk-nav-dropdown uk-nav-parent-icon">
                                            <li><a href="@route('/collections/entry/'.$collection["_id"])/@@ entry._id @@"><i class="uk-icon-pencil"></i> @lang('Edit entry')</a></li>
                                            <li><a href="#" data-ng-click="duplicate($index, entry._id)"><i class="uk-icon-copy"></i> @lang('Copy entry')</a></li>
                                            <li><a href="#" data-ng-click="remove($index, entry._id)"><i class="uk-icon-trash-o"></i> @lang('Delete entry')</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <div class="uk-margin-top">
                    @if($collection['sortfield'] != 'custom-order')
                    <button class="uk-button uk-button-primary" data-ng-click="loadmore()" data-ng-show="entries && !nomore">@lang('Load more...')</button>
                    @endif
                    <button class="uk-button uk-button-danger" data-ng-click="removeSelected()" data-ng-show="selected"><i class="uk-icon-trash-o"></i> @lang('Delete entries')</button>
                </div>

            </div>
        </div>
</div>
