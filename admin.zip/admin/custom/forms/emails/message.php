<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<body>
    <p>Пользователь отправил сообщение через сайт.</p>
    <p>Имя: {{$name}}</p>
    <p>email: {{$email2}}</p>
    <p>Текст сообщения:</p>
    <p>{{$message}}</p>
</body>
</html>