<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<body>
    <p>Пользователь заказал песню.</p>
    <p>Имя: {{$name}}</p>
    <p>Для кого: {{$for_name}}</p>
    <p>Название песни: {{$song}}</p>
    <p>Город: {{$city}}</p>
    <p>Номер телефона: {{$phone}}</p>
    <p>Сообщение: {{$message}}</p>
</body>
</html>