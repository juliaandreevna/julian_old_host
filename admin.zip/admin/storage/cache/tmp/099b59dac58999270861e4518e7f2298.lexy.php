<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<body>
    <p>Пользователь отправил заявку на добавление объекта.</p>
    <p>Имя: <?php echo $name; ?></p>
  	<p>Телефон: <?php echo $phone; ?></p>
  	<p>Город: <?php echo $addr1; ?>. Улица: <?php echo $addr2; ?>. Дом: <?php echo $addr3; ?>. Корпус: <?php echo $addr4; ?>. Квартира: <?php echo $addr5; ?>. Офис: <?php echo $addr6; ?>.</p>
  	<p>Дата: <?php echo $date; ?>.</p>
<p>ТОВАРЫ:</p>
  	<?php foreach($items as $key => $item) { ?>
    <p><?php echo $item['name']; ?></p>
    Начинки:	<?php echo $item['fills']; ?><br>
  	---------------------------<br>
    <?php } ?>
  <br>
  	<p>Итого: <?php echo $total; ?></p>
  	<p>Способ доставки: <?php echo $delivery; ?></p>
    <p>Сообщение: <?php echo $message; ?></p>
</body>
</html>